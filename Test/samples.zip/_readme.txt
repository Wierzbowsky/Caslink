Use the following command to run the games:

bload"cas:",r

The Firebird and Penguin games are for MSX2 computers only. 
